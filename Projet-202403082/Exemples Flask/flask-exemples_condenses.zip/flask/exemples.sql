CREATE TABLE `personnes` (
	`id`	INTEGER PRIMARY KEY AUTOINCREMENT,
	`nom`	TEXT,
	`prenom`	TEXT,
	`role`	INTEGER
);
